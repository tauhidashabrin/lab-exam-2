
<?php

session_start();



if (isset($_POST['login'])) {
	$id = $_POST['id'];
	$pass = $_POST['pass'];
 }

	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="user";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
 
 
    $query = "SELECT * FROM users WHERE id='$id' AND password='$pass'";
    $results = mysqli_query($conn, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['id'] = $id;
	while($row = mysqli_fetch_assoc($result)) {
	  $_SESSION['name '] = $row["name"];
	  $_SESSION['type '] = $row["type"];
	  }
	  if($_SESSION['type '] == 0){
      header('location: public_layout.html');}
	  elseif($_SESSION['type '] == 1){
      header('location: profile.html');}
    }
	
	else{
		header("location: registration.html");
	}

?>


<fieldset>
    <legend><b>LOGIN</b></legend>
    <form>
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" value="Submit">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>