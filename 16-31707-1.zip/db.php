<?php

	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="user";
	
	if (isset($_POST['submitted'])) {
		
		$id = $_POST['id'];
		$pass = $_POST['pass'];
		$name = $_POST['name'];
		
		if($_POST['type']=='user'){
			$type=1;
		}
		elseif($_POST['type']=='admin'){
			$type=0;
		}
		else{
			$type=-1;
		}
	}
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
		
	$sql = "insert into users values($id,'$pass','$name',$type)";
	
	if(mysqli_query($conn, $sql)){
		echo " Account Created! <br/>";
	}else{
		echo "<br/> SQL Error".mysqli_error($conn);
	}

	mysqli_close($conn);

?>