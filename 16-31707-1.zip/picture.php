<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form>
        <img width="128" src="../image/user.png" />
        <br />
        <input type="file">
        <hr />
        <input type="submit" value="Submit">
    </form>
</fieldset>